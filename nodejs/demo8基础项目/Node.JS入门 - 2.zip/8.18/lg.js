var http = require('http'),
fs = require('fs'),
urlLib = require('url');

var vip = {
	'Ly':123
}

http.createServer(function(req,res){
	res.setHeader('Access-Control-Allow-Origin','*');
	var json = urlLib.parse(req.url,true).query;

	if(vip[json.user]){
		res.write('管理员账号不可侵犯');
		res.end();
		return;
	}


	fs.readFile('./账号管理.txt','utf8',function(err,data){
		if(err){
			console.log(err);
		}
		else{
			var jsonDate = eval('('+data+')');

			if(jsonDate[json.user]){
				res.write('用户名已注册');
				res.end();
			}
			else{
				jsonDate[json.user] = json.pass;

				fs.writeFile('./账号管理.txt',JSON.stringify(jsonDate),function(err){
					if(err){
						console.log(err);
					}
					else{
						res.write('恭喜！注册成功～');
						res.end();
					}
				})
				


			}
		}
	});


}).listen(2933);


http.createServer(function(req,res){
	res.setHeader('Access-Control-Allow-Origin','*');
	var json = urlLib.parse(req.url,true).query;

	fs.readFile('./账号管理.txt','utf8',function(err,data){
		var jsonDate = eval('('+data+')');
		var arr = [];
		for(var i in jsonDate){
			arr.push(i);
		};

		res.write(JSON.stringify(arr));
		res.end();

	});


}).listen(8881);
http.createServer(function(req,res){
	res.setHeader('Access-Control-Allow-Origin','*');
	var json = urlLib.parse(req.url,true).query;

	if(vip[json.user] == json.pass){

		res.write('大人您回来了～');
		res.end();
		return;
	}

	fs.readFile('./账号管理.txt','utf8',function(err,data){
		if(err){
			console.log(err);
		}
		else{
			var jsonDate = eval('('+data+')');

			if(jsonDate[json.user] == json.pass){
				res.write('登陆成功');
				res.end();
			}
			else{
				res.write('用户名或密码错误');
				res.end();
			}
		}
	});


}).listen(2934);

http.createServer(function(req,res){
	res.setHeader('Access-Control-Allow-Origin','*');
	var json = urlLib.parse(req.url,true).query;

	console.log(json.user);


}).listen(9992);


http.createServer(function(req,res){
	res.setHeader('Access-Control-Allow-Origin','*');
	var json = urlLib.parse(req.url,true).query;

	fs.readFile('./文章列表.txt','utf8',function(err,data){
		if(err){
			console.log(err);
		}
		else{
			res.write(data);
			res.end();
		}
	});



	

}).listen(2936);

http.createServer(function(req,res){
	res.setHeader('Access-Control-Allow-Origin','*');
	var json = urlLib.parse(req.url,true).query;

	fs.readFile('./文章列表/'+json.inner+'.txt','utf8',function(err,data){
		if(err){
			console.log(err);
		}
		else{
			res.write(data);
			res.end();
		}
	});



	

}).listen(2937);
http.createServer(function(req,res){
	res.setHeader('Access-Control-Allow-Origin','*');
	var json = urlLib.parse(req.url,true).query;

	fs.readFile('./文章列表.txt','utf8',function(err,data){
		if(err){
			console.log(err);
		}
		else{
			var jsonDate = eval('('+data+')');
			jsonDate.push(json.fileName);
			fs.writeFile('./文章列表.txt',JSON.stringify(jsonDate),function(err){
				if(err){
					console.log(err);
				}
				else{
					fs.writeFile('./文章列表/'+json.fileName+'.txt',json.inner,function(err){
						if(err){
							console.log(err);
						}
						else{
							res.write('发布成功');
							res.end();
						}
					});


					
				}
			})	
		}
	});



	

}).listen(2935);



